"""
Tests for LangChain integration validation.

FUNDAMENTAL PRINCIPLE:
- AI/LangChain provides input (agent tool calls)
- APE parses, validates, and decides
- LangChain agents never execute logic directly

These tests verify that:
1. LangChain agent output is treated as untrusted input
2. All validation happens in APE runtime
3. Unstructured/invalid agent output is rejected deterministically
"""

import pytest
from unittest.mock import Mock
from typing import Any, Dict

from ape_langchain.tools import ApeLangChainTool


# ============================================================================
# POSITIVE TESTS - Expected Valid Use
# ============================================================================


class TestValidLangChainInput:
    """Test that valid LangChain agent tool calls are accepted."""

    def test_valid_structured_parameters_accepted(self):
        """LangChain agent output with correct structure passes APE validation."""
        # Mock APE module
        mock_signature = Mock()
        mock_signature.name = "add"
        mock_signature.inputs = {"a": "int", "b": "int"}
        mock_signature.output = "int"
        mock_signature.description = "Add two numbers"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.return_value = 8

        tool = ApeLangChainTool(mock_module, "add")

        # LangChain agent calls tool with valid kwargs
        result = tool.execute(a=5, b=3)

        assert result == 8
        mock_module.call.assert_called_once_with("add", a=5, b=3)

    def test_zero_parameter_tool_accepted(self):
        """LangChain agent calling zero-parameter tool works."""
        mock_signature = Mock()
        mock_signature.name = "get_timestamp"
        mock_signature.inputs = {}
        mock_signature.output = "str"
        mock_signature.description = "Get current timestamp"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.return_value = "2025-12-07T10:30:00Z"

        tool = ApeLangChainTool(mock_module, "get_timestamp")
        result = tool.execute()

        assert result == "2025-12-07T10:30:00Z"

    def test_structured_output_only_accepted(self):
        """LangChain agent must provide structured kwargs, not strings."""
        mock_signature = Mock()
        mock_signature.name = "process"
        mock_signature.inputs = {"data": "dict", "mode": "str"}
        mock_signature.output = "dict"
        mock_signature.description = "Process data"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.return_value = {"status": "ok"}

        tool = ApeLangChainTool(mock_module, "process")

        # Structured input
        result = tool.execute(data={"key": "value"}, mode="fast")

        assert result == {"status": "ok"}

    def test_all_required_fields_provided(self):
        """LangChain agent provides complete parameter set."""
        mock_signature = Mock()
        mock_signature.name = "calculate"
        mock_signature.inputs = {
            "x": "float",
            "y": "float",
            "operation": "str"
        }
        mock_signature.output = "float"
        mock_signature.description = "Calculate"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.return_value = 15.0

        tool = ApeLangChainTool(mock_module, "calculate")
        result = tool.execute(x=10.0, y=5.0, operation="add")

        assert result == 15.0


# ============================================================================
# NEGATIVE TESTS - Invalid/Unstructured Agent Output
# ============================================================================


class TestLangChainInvalidInputRejected:
    """
    Test that unstructured or invalid LangChain agent output is rejected.
    
    CRITICAL: LangChain agents can send creative/malformed tool calls.
    APE must reject anything that doesn't match the contract.
    """

    def test_missing_required_parameter_rejected(self):
        """LangChain agent forgets required parameter → APE rejects."""
        mock_signature = Mock()
        mock_signature.name = "multiply"
        mock_signature.inputs = {"a": "int", "b": "int"}
        mock_signature.output = "int"
        mock_signature.description = "Multiply"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        tool = ApeLangChainTool(mock_module, "multiply")

        # Agent forgets 'b'
        with pytest.raises(TypeError) as exc_info:
            tool.execute(a=5)

        assert "Missing required arguments" in str(exc_info.value)
        assert "{'b'}" in str(exc_info.value)

    def test_extra_hallucinated_parameter_rejected(self):
        """LangChain agent invents extra parameter → APE rejects."""
        mock_signature = Mock()
        mock_signature.name = "square"
        mock_signature.inputs = {"x": "int"}
        mock_signature.output = "int"
        mock_signature.description = "Square"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        tool = ApeLangChainTool(mock_module, "square")

        # Agent hallucinates 'y' and 'verbose'
        with pytest.raises(TypeError) as exc_info:
            tool.execute(x=5, y=10, verbose=True)

        assert "Unknown arguments" in str(exc_info.value)

    def test_unstructured_string_input_rejected(self):
        """LangChain agent sends unstructured string → APE cannot parse."""
        mock_signature = Mock()
        mock_signature.name = "parse"
        mock_signature.inputs = {"data": "dict"}
        mock_signature.output = "dict"
        mock_signature.description = "Parse data"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.side_effect = TypeError("Expected dict, got str")

        tool = ApeLangChainTool(mock_module, "parse")

        # Agent sends unstructured text instead of dict
        with pytest.raises(Exception):
            tool.execute(data="some random text from agent")

    def test_wrong_type_in_parameter_rejected(self):
        """LangChain agent sends wrong type → APE validates."""
        mock_signature = Mock()
        mock_signature.name = "repeat"
        mock_signature.inputs = {"count": "int"}
        mock_signature.output = "str"
        mock_signature.description = "Repeat"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.side_effect = TypeError("Expected int, got str")

        tool = ApeLangChainTool(mock_module, "repeat")

        # Agent sends string instead of int
        with pytest.raises(Exception):
            tool.execute(count="five")

    def test_hallucinated_tool_name_rejected(self):
        """LangChain agent calls non-existent tool → APE rejects."""
        mock_module = Mock()
        mock_module.get_function_signature.side_effect = KeyError("Not found")
        mock_module.list_functions.return_value = ["add", "subtract"]

        with pytest.raises(KeyError) as exc_info:
            ApeLangChainTool(mock_module, "magical_do_everything")

        assert "not found" in str(exc_info.value)

    def test_partial_incomplete_parameters_rejected(self):
        """LangChain agent sends partial/incomplete parameters → APE rejects."""
        mock_signature = Mock()
        mock_signature.name = "configure"
        mock_signature.inputs = {
            "host": "str",
            "port": "int",
            "timeout": "int"
        }
        mock_signature.output = "bool"
        mock_signature.description = "Configure"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        tool = ApeLangChainTool(mock_module, "configure")

        # Agent sends incomplete set
        with pytest.raises(TypeError) as exc_info:
            tool.execute(host="localhost", port=8080)
            # Missing 'timeout'

        assert "Missing required arguments" in str(exc_info.value)

    def test_null_values_in_required_fields_rejected(self):
        """LangChain agent sends null/None → APE validates."""
        mock_signature = Mock()
        mock_signature.name = "compute"
        mock_signature.inputs = {"value": "int"}
        mock_signature.output = "int"
        mock_signature.description = "Compute"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.side_effect = TypeError("Cannot process None")

        tool = ApeLangChainTool(mock_module, "compute")

        with pytest.raises(Exception):
            tool.execute(value=None)


# ============================================================================
# DECISION AUTHORITY VERIFICATION
# ============================================================================


class TestAPEDecisionAuthorityLangChain:
    """
    Verify that APE runtime has exclusive decision authority.
    
    LangChain agent output is ONLY input. APE makes ALL execution decisions.
    """

    def test_langchain_cannot_bypass_validation(self):
        """LangChain agent cannot force execution with metadata flags."""
        mock_signature = Mock()
        mock_signature.name = "func"
        mock_signature.inputs = {"x": "int"}
        mock_signature.output = "int"
        mock_signature.description = "Function"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        tool = ApeLangChainTool(mock_module, "func")

        # Agent tries clever bypass
        with pytest.raises(TypeError) as exc_info:
            tool.execute(
                x=5,
                _force_execute=True,
                _skip_validation=True
            )

        assert "Unknown arguments" in str(exc_info.value)

    def test_agent_output_never_directly_executed(self):
        """Agent output goes through APE validation, never direct execution."""
        mock_signature = Mock()
        mock_signature.name = "add"
        mock_signature.inputs = {"a": "int", "b": "int"}
        mock_signature.output = "int"
        mock_signature.description = "Add"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.return_value = 8

        tool = ApeLangChainTool(mock_module, "add")

        # Agent provides input
        result = tool.execute(a=5, b=3)

        # APE runtime.call() was invoked (APE decides execution)
        mock_module.call.assert_called_once_with("add", a=5, b=3)
        assert result == 8

    def test_validation_before_execution(self):
        """Validation happens BEFORE execution logic runs."""
        mock_signature = Mock()
        mock_signature.name = "process"
        mock_signature.inputs = {"data": "dict"}
        mock_signature.output = "dict"
        mock_signature.description = "Process"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        tool = ApeLangChainTool(mock_module, "process")

        # Agent sends invalid (missing parameter)
        with pytest.raises(TypeError):
            tool.execute()  # No arguments

        # Execution never called
        mock_module.call.assert_not_called()

    def test_deterministic_rejection_same_invalid_input(self):
        """Same invalid input rejected identically every time (deterministic)."""
        mock_signature = Mock()
        mock_signature.name = "calc"
        mock_signature.inputs = {"x": "int"}
        mock_signature.output = "int"
        mock_signature.description = "Calculate"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        tool = ApeLangChainTool(mock_module, "calc")

        # Run 10 times with same invalid input (has x but also extra)
        for _ in range(10):
            with pytest.raises(TypeError) as exc_info:
                tool.execute(x=5, wrong_param=10)

            assert "Unknown arguments" in str(exc_info.value)

        # Execution never attempted
        mock_module.call.assert_not_called()


# ============================================================================
# NO RECOVERY / NO BEST EFFORT
# ============================================================================


class TestNoRecoveryLangChain:
    """
    Verify that invalid LangChain agent output is REJECTED, not recovered.
    
    No heuristics, no fuzzy matching, no silent fixes.
    Invalid input → structured error → stop.
    """

    def test_no_parameter_name_fuzzy_matching(self):
        """Parameter names must match exactly, no fuzzy matching."""
        mock_signature = Mock()
        mock_signature.name = "func"
        mock_signature.inputs = {"username": "str"}
        mock_signature.output = "str"
        mock_signature.description = "Function"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        tool = ApeLangChainTool(mock_module, "func")

        # Agent uses similar but wrong name
        with pytest.raises(TypeError) as exc_info:
            tool.execute(user_name="john")  # Wrong: underscore

        # No fuzzy matching attempted
        assert "Unknown arguments" in str(exc_info.value) or "Missing required" in str(exc_info.value)

    def test_no_type_coercion_attempted(self):
        """Wrong types are NOT silently coerced."""
        mock_signature = Mock()
        mock_signature.name = "func"
        mock_signature.inputs = {"count": "int"}
        mock_signature.output = "int"
        mock_signature.description = "Function"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.side_effect = TypeError("Expected int, got str")

        tool = ApeLangChainTool(mock_module, "func")

        # Agent sends string
        with pytest.raises(Exception):
            tool.execute(count="10")  # String, not int

    def test_structured_error_with_context(self):
        """Failures produce structured errors with context."""
        mock_signature = Mock()
        mock_signature.name = "func"
        mock_signature.inputs = {"a": "int", "b": "int"}
        mock_signature.output = "int"
        mock_signature.description = "Function"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        tool = ApeLangChainTool(mock_module, "func")

        with pytest.raises(TypeError) as exc_info:
            tool.execute(a=5, c=10)  # Wrong param 'c'

        error_message = str(exc_info.value)
        # Error contains useful context
        assert "Unknown arguments" in error_message or "Missing required" in error_message

    def test_no_silent_failure_on_invalid_input(self):
        """Invalid input raises exception, never silent."""
        mock_signature = Mock()
        mock_signature.name = "func"
        mock_signature.inputs = {"x": "int"}
        mock_signature.output = "int"
        mock_signature.description = "Function"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        tool = ApeLangChainTool(mock_module, "func")

        # Must raise, not return None or default
        with pytest.raises(TypeError):
            tool.execute()  # Missing 'x'

    def test_unstructured_text_never_parsed_as_parameters(self):
        """Unstructured agent text is not parsed into parameters."""
        mock_signature = Mock()
        mock_signature.name = "func"
        mock_signature.inputs = {"x": "int", "y": "int"}
        mock_signature.output = "int"
        mock_signature.description = "Function"

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        tool = ApeLangChainTool(mock_module, "func")

        # If agent sends unstructured text (shouldn't happen with StructuredTool)
        # APE would reject it. Here we verify structured input is required.
        with pytest.raises(TypeError):
            # No creative parsing of arbitrary strings
            tool.execute()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
