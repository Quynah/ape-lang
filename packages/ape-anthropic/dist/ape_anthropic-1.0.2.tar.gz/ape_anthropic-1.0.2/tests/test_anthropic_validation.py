"""
Tests for Anthropic Claude integration validation.

FUNDAMENTAL PRINCIPLE:
- AI provides input (Claude tool use responses)
- APE parses, validates, and decides
- Claude never executes logic directly

These tests verify that:
1. Claude output is treated as untrusted input
2. All validation happens in APE runtime
3. Invalid/hallucinated Claude output is rejected deterministically
"""

import pytest
from unittest.mock import Mock
import json

from ape_anthropic.executor import execute_claude_call


# ============================================================================
# POSITIVE TESTS - Expected Valid Use
# ============================================================================


class TestValidClaudeInput:
    """Test that valid Claude tool use responses are accepted."""

    def test_valid_parameters_accepted(self):
        """Claude output with correct parameters passes APE validation."""
        # Mock APE module
        mock_signature = Mock()
        mock_signature.inputs = {"a": "int", "b": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.return_value = 8

        # Claude response: valid parameters
        claude_arguments = {"a": 5, "b": 3}

        result = execute_claude_call(mock_module, "add", claude_arguments)

        assert result == 8
        mock_module.call.assert_called_once_with("add", a=5, b=3)

    def test_dict_arguments_accepted(self):
        """Claude output as dict is validated directly."""
        mock_signature = Mock()
        mock_signature.inputs = {"x": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.return_value = 25

        # Claude sends dict
        claude_input = {"x": 5}

        result = execute_claude_call(mock_module, "square", claude_input)

        assert result == 25
        mock_module.call.assert_called_once_with("square", x=5)

    def test_empty_parameters_accepted(self):
        """Claude output with no parameters works for zero-arg functions."""
        mock_signature = Mock()
        mock_signature.inputs = {}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.return_value = "2025-12-07T10:30:00Z"

        claude_arguments = {}

        result = execute_claude_call(mock_module, "get_timestamp", claude_arguments)

        assert result == "2025-12-07T10:30:00Z"

    def test_all_required_parameters_provided(self):
        """Claude output with all required fields passes validation."""
        mock_signature = Mock()
        mock_signature.inputs = {
            "amount": "float",
            "rate": "float",
            "years": "int"
        }

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.return_value = 1276.28

        claude_arguments = {
            "amount": 1000.0,
            "rate": 0.05,
            "years": 5
        }

        result = execute_claude_call(
            mock_module,
            "calculate_compound_interest",
            claude_arguments
        )

        assert result == 1276.28


# ============================================================================
# NEGATIVE TESTS - Invalid/Hallucinated Claude Output
# ============================================================================


class TestClaudeHallucinationsRejected:
    """
    Test that hallucinated/invalid Claude output is rejected.
    
    CRITICAL: These tests prove APE has decision authority.
    Claude cannot bypass validation by sending creative/incorrect data.
    """

    def test_missing_required_parameter_rejected(self):
        """Claude hallucination: missing required field → APE rejects."""
        mock_signature = Mock()
        mock_signature.inputs = {"a": "int", "b": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        # Claude hallucinates: forgets parameter 'b'
        hallucinated_arguments = {"a": 5}

        with pytest.raises(TypeError) as exc_info:
            execute_claude_call(mock_module, "add", hallucinated_arguments)

        assert "Missing required arguments" in str(exc_info.value)
        assert "{'b'}" in str(exc_info.value)

    def test_extra_parameter_rejected(self):
        """Claude hallucination: invents non-existent parameter → APE rejects."""
        mock_signature = Mock()
        mock_signature.inputs = {"x": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        # Claude hallucinates: adds 'y' and 'verbose' that don't exist
        hallucinated_arguments = {"x": 5, "y": 10, "verbose": True}

        with pytest.raises(TypeError) as exc_info:
            execute_claude_call(mock_module, "square", hallucinated_arguments)

        assert "Unknown arguments" in str(exc_info.value)

    def test_hallucinated_function_name_rejected(self):
        """Claude hallucination: calls non-existent function → APE rejects."""
        mock_module = Mock()
        mock_module.get_function_signature.side_effect = KeyError("Not found")
        mock_module.list_functions.return_value = ["add", "subtract"]

        # Claude hallucinates function name
        hallucinated_arguments = {"x": 5}

        with pytest.raises(KeyError) as exc_info:
            execute_claude_call(
                mock_module,
                "magical_compute_everything",
                hallucinated_arguments
            )

        assert "not found" in str(exc_info.value)

    def test_wrong_type_rejected(self):
        """Claude hallucination: sends string instead of int → APE rejects."""
        mock_signature = Mock()
        mock_signature.inputs = {"count": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        # Simulate type error during execution
        mock_module.call.side_effect = TypeError("expected int, got str")

        # Claude sends wrong type
        hallucinated_arguments = {"count": "five"}

        with pytest.raises(Exception) as exc_info:
            execute_claude_call(mock_module, "repeat", hallucinated_arguments)

        # APE runtime catches type errors
        assert "failed" in str(exc_info.value).lower() or "expected int" in str(exc_info.value)

    def test_nested_structure_mismatch_rejected(self):
        """Claude hallucination: wrong nested structure → APE rejects."""
        mock_signature = Mock()
        mock_signature.inputs = {"data": "dict"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        # Claude sends list instead of dict
        hallucinated_arguments = {"data": [1, 2, 3]}

        # APE would catch this during runtime validation
        mock_module.call.side_effect = TypeError("Expected dict, got list")

        with pytest.raises(Exception):
            execute_claude_call(mock_module, "process", hallucinated_arguments)

    def test_partial_truncated_payload_rejected(self):
        """Claude hallucination: incomplete/truncated response → APE rejects."""
        mock_signature = Mock()
        mock_signature.inputs = {
            "field_a": "str",
            "field_b": "str",
            "field_c": "str"
        }

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        # Claude truncates mid-response
        truncated_arguments = {
            "field_a": "value1",
            "field_b": "value2"
            # Missing field_c
        }

        with pytest.raises(TypeError) as exc_info:
            execute_claude_call(mock_module, "func", truncated_arguments)

        assert "Missing required arguments" in str(exc_info.value)

    def test_null_value_in_required_field_rejected(self):
        """Claude hallucination: null/None in required field → APE validates."""
        mock_signature = Mock()
        mock_signature.inputs = {"value": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.side_effect = TypeError("Cannot process None")

        # Claude sends null
        hallucinated_arguments = {"value": None}

        with pytest.raises(Exception):
            execute_claude_call(mock_module, "compute", hallucinated_arguments)

    def test_mixed_valid_invalid_parameters_rejected(self):
        """Claude hallucination: some valid, some invalid → APE rejects all."""
        mock_signature = Mock()
        mock_signature.inputs = {"a": "int", "b": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        # Claude sends valid 'a', invalid extra 'c'
        mixed_arguments = {"a": 5, "b": 10, "c": 15}

        with pytest.raises(TypeError) as exc_info:
            execute_claude_call(mock_module, "add", mixed_arguments)

        assert "Unknown arguments" in str(exc_info.value)


# ============================================================================
# DECISION AUTHORITY VERIFICATION
# ============================================================================


class TestAPEDecisionAuthority:
    """
    Verify that APE runtime has exclusive decision authority.
    
    Claude output is ONLY input. APE makes ALL execution decisions.
    """

    def test_claude_cannot_bypass_validation(self):
        """Claude cannot execute functions by sending 'creative' payloads."""
        mock_signature = Mock()
        mock_signature.inputs = {"x": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        # Claude tries to be clever: adds metadata
        creative_payload = {
            "x": 5,
            "_execute_anyway": True,
            "_bypass_validation": True,
            "_force": True
        }

        # APE rejects extra fields
        with pytest.raises(TypeError) as exc_info:
            execute_claude_call(mock_module, "func", creative_payload)

        assert "Unknown arguments" in str(exc_info.value)

    def test_claude_output_parsed_never_executed(self):
        """Claude output goes through parsing, not direct execution."""
        mock_signature = Mock()
        mock_signature.inputs = {}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.return_value = "result"

        # Claude sends valid arguments
        claude_output = {}

        result = execute_claude_call(mock_module, "func", claude_output)

        # Verify APE runtime.call() was invoked (APE decides execution)
        mock_module.call.assert_called_once_with("func")
        assert result == "result"

    def test_ape_validates_before_execution(self):
        """Validation happens BEFORE any execution logic runs."""
        mock_signature = Mock()
        mock_signature.inputs = {"a": "int", "b": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        # Claude sends invalid (missing parameter)
        invalid_arguments = {"a": 5}

        with pytest.raises(TypeError):
            execute_claude_call(mock_module, "add", invalid_arguments)

        # Execution never called because validation failed first
        mock_module.call.assert_not_called()

    def test_deterministic_rejection_of_invalid_input(self):
        """Same invalid input always rejected (deterministic)."""
        mock_signature = Mock()
        mock_signature.inputs = {"x": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        invalid_arguments = {"x": 5, "wrong_field": 10}

        # Run 10 times - should fail identically every time
        for _ in range(10):
            with pytest.raises(TypeError) as exc_info:
                execute_claude_call(mock_module, "func", invalid_arguments)

            assert "Unknown arguments" in str(exc_info.value)

        # Execution never attempted
        mock_module.call.assert_not_called()


# ============================================================================
# NO RECOVERY / NO BEST EFFORT
# ============================================================================


class TestNoRecoveryNoBestEffort:
    """
    Verify that invalid Claude output is REJECTED, not recovered.
    
    No heuristics, no retries, no silent fixes.
    Invalid input → structured error → stop.
    """

    def test_no_parameter_guessing(self):
        """Missing parameters are NOT guessed or defaulted."""
        mock_signature = Mock()
        mock_signature.inputs = {"a": "int", "b": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        # Missing 'b'
        incomplete_arguments = {"a": 5}

        with pytest.raises(TypeError) as exc_info:
            execute_claude_call(mock_module, "add", incomplete_arguments)

        # Error is explicit, no silent defaulting
        assert "Missing required arguments" in str(exc_info.value)

    def test_no_type_coercion_recovery(self):
        """Wrong types are NOT silently coerced."""
        mock_signature = Mock()
        mock_signature.inputs = {"x": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature
        mock_module.call.side_effect = TypeError("Cannot convert str to int")

        # Wrong type
        wrong_type_arguments = {"x": "not_a_number"}

        with pytest.raises(Exception) as exc_info:
            execute_claude_call(mock_module, "compute", wrong_type_arguments)

        # No silent conversion attempted
        assert "failed" in str(exc_info.value).lower() or "convert" in str(exc_info.value).lower()

    def test_structured_error_on_failure(self):
        """Failures produce structured errors with context."""
        mock_signature = Mock()
        mock_signature.inputs = {"a": "int", "b": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        invalid_arguments = {"a": 5, "b": 3, "extra": 10}

        with pytest.raises(TypeError) as exc_info:
            execute_claude_call(mock_module, "add", invalid_arguments)

        error_message = str(exc_info.value)
        # Error contains useful context
        assert "Unknown arguments" in error_message
        assert "extra" in error_message

    def test_no_silent_failure(self):
        """Invalid input raises exception, never silent."""
        mock_signature = Mock()
        mock_signature.inputs = {"x": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        invalid_arguments = {}

        # Must raise, not return None or empty result
        with pytest.raises(TypeError):
            execute_claude_call(mock_module, "func", invalid_arguments)

    def test_no_creative_error_recovery(self):
        """APE does not attempt creative recovery from Claude errors."""
        mock_signature = Mock()
        mock_signature.inputs = {"value": "int"}

        mock_module = Mock()
        mock_module.get_function_signature.return_value = mock_signature

        # Claude sends completely wrong structure
        wrong_structure = {"wrong_name": "wrong_value"}

        with pytest.raises(TypeError):
            execute_claude_call(mock_module, "func", wrong_structure)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
