"""
Ape CLI entry point

Allows running: python -m ape <command>
"""

from ape.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
