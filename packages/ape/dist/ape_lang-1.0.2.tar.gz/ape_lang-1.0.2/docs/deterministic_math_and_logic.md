# Deterministic Math & Logic in APE

**Version:** APE v1.0.2 (stdlib extension)  
**Status:** Production-ready  
**Purpose:** Type-strict, deterministic primitives for decision logic and rule evaluation

---

## Overview

APE's standard library provides **20+ deterministic primitive functions** across comparison, logic, math, and collection operations. These primitives are designed for **high-stakes decision automation** where type safety, determinism, and explicit error handling are critical.

### Key Principles

1. **Determinism**: Same input → same output, every time (100-iteration tested)
2. **Type strictness**: No implicit coercion (`1 ≠ 1.0`, no truthy/falsy)
3. **Explicit errors**: Operation name + type info in every error
4. **No side effects**: Pure functions only, no I/O or randomness
5. **Traceability**: All errors observable in execution traces

---

## Comparison Operators

**Module:** `ape.std.comparison`  
**Purpose:** Type-strict equality and ordering operations

### Functions

```python
eq(a, b) -> bool           # Strict equality (1 ≠ 1.0)
neq(a, b) -> bool          # Strict inequality
lt(a, b) -> bool           # Less than
lte(a, b) -> bool          # Less than or equal
gt(a, b) -> bool           # Greater than
gte(a, b) -> bool          # Greater than or equal
```

### Type Rules

- **No type coercion**: `eq(1, 1.0)` raises `ComparisonTypeError`
- **None not comparable**: `eq(x, None)` raises error
- **Booleans not orderable**: `lt(True, False)` raises error (but `eq(True, True)` works)
- **Supported types for ordering**: `int`, `float`, `str`

### Examples

```python
from ape.std.comparison import eq, lt

# ✅ Valid comparisons
eq(5, 5)           → True
eq(5, 6)           → False
lt(3, 5)           → True
eq("a", "a")       → True

# ❌ Type mismatches raise ComparisonTypeError
eq(1, 1.0)         → ComparisonTypeError("eq", int, float)
lt(5, "5")         → ComparisonTypeError("lt", int, str)
eq(x, None)        → ComparisonTypeError("eq", int, NoneType)
```

### Why Type Strictness?

In medical/safety-critical systems, **silent type coercion masks bugs**:

```python
# ❌ Python's == (dangerous in production)
risk_score = 80          # int from database
threshold = 80.0         # float from config
risk_score == threshold  # True (silent coercion)

# ✅ APE's eq (explicit failure)
eq(risk_score, threshold)  # ComparisonTypeError("eq", int, float)
# Forces developer to fix: convert both to same type explicitly
```

---

## Boolean Logic Operators

**Module:** `ape.std.logic`  
**Purpose:** Strict boolean operations (no truthy/falsy coercion)

### Functions

```python
and_op(a: bool, b: bool) -> bool    # Logical AND
or_op(a: bool, b: bool) -> bool     # Logical OR
not_op(a: bool) -> bool             # Logical NOT
```

### Type Rules

- **Strict boolean type**: Only `True` and `False` accepted
- **No truthy/falsy**: `and_op(1, True)` raises `LogicTypeError`
- **No short-circuit**: Both args always evaluated (determinism)

### Examples

```python
from ape.std.logic import and_op, or_op, not_op

# ✅ Valid logic operations
and_op(True, True)     → True
and_op(True, False)    → False
or_op(False, True)     → True
not_op(False)          → True

# ❌ Non-booleans raise LogicTypeError
and_op(1, True)        → LogicTypeError("and_op", "a", int)
or_op(True, "yes")     → LogicTypeError("or_op", "b", str)
not_op([])             → LogicTypeError("not_op", "a", list)
```

### Why No Truthy/Falsy?

Python's truthy/falsy semantics are **ambiguous in decision logic**:

```python
# ❌ Python's and (dangerous in production)
user_override = []      # Empty list = False
high_risk = True
if high_risk and user_override:  # False (wrong intent!)
    escalate()

# ✅ APE's and_op (explicit failure)
and_op(high_risk, user_override)  # LogicTypeError("and_op", "b", list)
# Forces developer to fix: convert to explicit bool
```

---

## Math Primitives

**Module:** `ape.std.math`  
**Purpose:** Deterministic arithmetic with explicit error handling

### Functions

```python
add(a, b) -> int | float         # Addition
sub(a, b) -> int | float         # Subtraction
mul(a, b) -> int | float         # Multiplication
div(a, b) -> float               # Division (always float)
div_int(a: int, b: int) -> int   # Integer floor division
mod(a: int, b: int) -> int       # Modulo (remainder)
```

### Type Rules

- **No booleans**: `add(True, 1)` raises `MathTypeError` (bool excluded from numeric)
- **Integer-first**: Operations on ints return int, mixed int/float return float
- **Explicit division by zero**: `DivisionByZeroError(numerator)` includes context

### Examples

```python
from ape.std.math import add, sub, mul, div, div_int, mod

# ✅ Valid math operations
add(5, 3)              → 8
sub(10, 7)             → 3
mul(4, 5)              → 20
div(10, 3)             → 3.333... (always float)
div_int(10, 3)         → 3 (floor division)
mod(10, 3)             → 1 (remainder)

# Mixed int/float returns float
add(5, 2.5)            → 7.5

# ❌ Invalid operations
add(True, 1)           → MathTypeError("add", "a", bool)
div(5, 0)              → DivisionByZeroError(5)
div_int(5.0, 2)        → MathTypeError("div_int", "a", float)
```

### Why Exclude Booleans?

In Python, `True == 1` and `False == 0`, enabling silent bugs:

```python
# ❌ Python's + (dangerous in production)
usage_minutes = [120, 45, True, 30]  # Bug: bool instead of int
total = sum(usage_minutes)           # 196 (True counted as 1)

# ✅ APE's add (explicit failure)
total = sum_list(usage_minutes)      # MathTypeError("sum_list", "items[2]", bool)
# Forces developer to fix: remove or convert the boolean
```

---

## Collection Aggregates

**Module:** `ape.std.collections`  
**Purpose:** Type-safe collection operations with validation

### Functions

```python
sum_list(items: List[int | float]) -> int | float    # Sum numbers
all_bool(items: List[bool]) -> bool                  # All True?
any_bool(items: List[bool]) -> bool                  # Any True?
unique(items: List) -> List                          # Remove duplicates (order-preserving)
length(items: List) -> int                           # Alias for count
```

### Type Rules

- **Element validation**: Every element checked for correct type
- **Empty collection behavior**:
  - `sum_list([])` raises `EmptyCollectionError` (explicit failure)
  - `all_bool([])` returns `True` (vacuous truth)
  - `any_bool([])` returns `False`
- **Order preservation**: `unique()` keeps first occurrence order

### Examples

```python
from ape.std.collections import sum_list, all_bool, any_bool, unique, length

# ✅ Valid operations
sum_list([1, 2, 3, 4])          → 10
all_bool([True, True, True])    → True
all_bool([True, False, True])   → False
any_bool([False, True, False])  → True
unique([1, 2, 1, 3, 2])         → [1, 2, 3]
length([1, 2, 3])               → 3

# ❌ Invalid operations
sum_list([])                    → EmptyCollectionError("sum_list")
sum_list([1, "2", 3])           → MathTypeError("sum_list", "items[1]", str)
all_bool([True, 1, False])      → CollectionTypeError("all_bool", "list[bool]", "int")
```

### Why Explicit Empty Errors?

Empty collections in aggregates are **often bugs**:

```python
# ❌ Python's sum (silent zero)
daily_usage = []  # Bug: no data collected
avg = sum(daily_usage) / len(daily_usage)  # ZeroDivisionError (late failure)

# ✅ APE's sum_list (early explicit failure)
total = sum_list(daily_usage)  # EmptyCollectionError("sum_list")
# Fails immediately with context, not later in division
```

---

## Error Hierarchy

**Module:** `ape.std.errors`  
**Purpose:** Explicit error types for deterministic debugging

### Error Types

```python
StdLibError                    # Base class for all stdlib errors
├── ComparisonTypeError        # Type mismatch in comparisons
├── MathTypeError              # Non-numeric in math operations
├── DivisionByZeroError        # Explicit zero division
├── LogicTypeError             # Non-boolean in logic operations
├── CollectionTypeError        # Wrong collection element type
└── EmptyCollectionError       # Operation requires non-empty collection
```

### Error Context

All errors include:
- **Operation name**: Which function failed
- **Parameter name**: Which argument was invalid (where applicable)
- **Type information**: Expected vs. received types

### Examples

```python
# ComparisonTypeError
eq(1, 1.0)  → "eq cannot compare int and float"

# MathTypeError
add(True, 1)  → "add requires number for a, got bool"

# DivisionByZeroError
div(10, 0)  → "Cannot divide 10 / 0"

# LogicTypeError
and_op(1, True)  → "and_op requires bool for a, got int"

# CollectionTypeError
all_bool([True, 1])  → "all_bool requires list[bool], got int"

# EmptyCollectionError
sum_list([])  → "sum_list requires non-empty collection"
```

---

## Design Rationale

### Why Not Use Python's Built-ins?

| Python Built-in | APE Alternative | Why Different? |
|-----------------|-----------------|----------------|
| `==`, `!=` | `eq()`, `neq()` | No type coercion (1 ≠ 1.0) |
| `and`, `or`, `not` | `and_op()`, `or_op()`, `not_op()` | No truthy/falsy, no short-circuit |
| `+`, `-`, `*`, `/` | `add()`, `sub()`, `mul()`, `div()` | Exclude booleans, explicit errors |
| `sum()` | `sum_list()` | Explicit empty error, type validation |
| `all()`, `any()` | `all_bool()`, `any_bool()` | Strict boolean lists only |

### Hard Constraints

1. **Determinism**: No side effects, no external state
   - ✅ Pure functions only
   - ❌ No filesystem, network, randomness, time-based behavior

2. **Language Purity**: No Python-specific quirks
   - ✅ Explicit types, no coercion
   - ❌ No truthy/falsy, no duck typing

3. **No Assumptions**: Pure primitives only
   - ✅ Generic comparison/math/logic
   - ❌ No domain logic (statistics, dates, business rules)

4. **No Breaking Changes**: All additions
   - ✅ Existing stdlib functions preserved
   - ✅ New functions are extensions

---

## Testing

All primitives tested with:
- **Determinism tests**: 100-iteration loops prove same input → same output
- **Type error tests**: Invalid types raise correct error with context
- **Edge case tests**: Empty collections, zero, negatives, large numbers
- **Truth table tests**: Complete boolean logic validation

**Test coverage**: 158 tests for new primitives, **610 total tests pass**.

---

## Usage in APE Programs

### Example: Risk Assessment Logic

```python
from ape.std.comparison import gt, lt
from ape.std.logic import and_op, or_op, not_op
from ape.std.math import sub
from ape.std.collections import sum_list, all_bool

# Risk scoring
def evaluate_risk(usage_minutes: list, threshold: int, override: bool) -> str:
    total_usage = sum_list(usage_minutes)
    avg_usage = div(total_usage, length(usage_minutes))
    
    high_risk = gt(avg_usage, threshold)
    escalate = and_op(high_risk, not_op(override))
    
    if escalate:
        return "ESCALATE"
    else:
        return "OK"

# Usage
result = evaluate_risk([120, 90, 150], 100, False)  # "ESCALATE"
```

### Example: Policy Rule Evaluation

```python
from ape.std.comparison import eq, gte
from ape.std.logic import and_op, all_bool

# Multi-condition policy check
def check_policy(age: int, consent: bool, verified: bool) -> bool:
    age_ok = gte(age, 13)
    permissions_ok = all_bool([consent, verified])
    return and_op(age_ok, permissions_ok)

# Usage
allowed = check_policy(15, True, True)   # True
blocked = check_policy(12, True, True)   # False (age < 13)
```

---

## Explicit Non-Goals

These are **intentionally excluded** to keep primitives deterministic:

❌ **Floating-point heuristics**: No `round()`, `floor()`, `ceil()` (non-deterministic across platforms)  
❌ **Statistics**: No `mean()`, `median()`, `stdev()` (domain-specific, not primitive)  
❌ **Trigonometry**: No `sin()`, `cos()`, `tan()` (floating-point instability)  
❌ **Date/time**: No `now()`, `date_diff()` (external state, non-deterministic)  
❌ **String parsing**: No `parse_int()`, `parse_float()` (locale-dependent)  
❌ **Random**: No `random()`, `choice()` (non-deterministic by definition)

For these operations, use **domain-specific libraries** in the host environment (Python, Node.js, etc.).

---

## Future Considerations

Potential future additions (not yet implemented):

1. **Bitwise operators**: `bit_and()`, `bit_or()`, `bit_xor()` for low-level logic
2. **Range checks**: `in_range(x, min, max)` for bounded validation
3. **List slicing**: `slice(items, start, end)` for deterministic sublist extraction
4. **Set operations**: `intersection()`, `union()`, `difference()` for set logic

---

## Version History

- **v1.0.2** (Dec 2024): Initial stdlib extension
  - 20+ deterministic primitives added
  - 7 explicit error types
  - 158 comprehensive tests
  - Full backward compatibility

---

## References

- **APE Language Spec**: `packages/ape/spec/APE_Spec_v0.1.md`
- **Source Code**: `packages/ape/src/ape/std/`
- **Tests**: `packages/ape/tests/std/`
- **Examples**: `packages/ape/examples/stdlib_complete.ape`
